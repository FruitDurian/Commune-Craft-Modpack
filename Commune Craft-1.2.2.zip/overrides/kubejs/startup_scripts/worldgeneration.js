onEvent('worldgen.remove', event => {
    event.removeOres(ores => {
      ores.blocks = [ 
        'create:copper_ore',
        'iceandfire:copper_ore',
        'thermal:copper_ore',
        'immersiveengineering:ore_copper',
        'iceandfire:silver_ore',
        'thermal:silver_ore',
        'immersiveengineering:ore_silver',
        'create:zinc_ore',
        'thermal:tin_ore',
        'immersiveengineering:ore_lead',
        'thermal:lead_ore',
        'immersiveengineering:ore_lead',
        'thermal:nickel_ore',
        'immersiveengineering:ore_aluminum',
        'immersiveengineering:ore_uranium',
        'alltheores:ore_osmium'
    ]
    })
})