
onEvent('jei.hide.items', event => {
	event.hide(Item.of('botania:flight_tiara', {variant:0}))
	event.hide ([
		// Copper
        'create:copper_ore',
        'iceandfire:copper_ore',
        'thermal:copper_ore',
        'immersiveengineering:ore_copper',
        // Silver
        'iceandfire:silver_ore',
        'thermal:silver_ore',
        'immersiveengineering:ore_silver',
        // Zinc 
        'create:zinc_ore',
        'thermal:tin_ore',
        // Lead
        'immersiveengineering:ore_lead',
        'thermal:lead_ore',
        'immersiveengineering:ore_lead',
        // Nickel
        'thermal:nickel_ore',
        // Bauxite or Aluminum
        'immersiveengineering:ore_aluminum',
        // Uranium
        'immersiveengineering:ore_uranium'
	])
	onEvent(`jei.hide.items`, e => {
		e.hide([
			`iceandfire:silver_ingot`,
			`iceandfire:copper_ingot`,
			`eidolon:sulfur`,
			`eidolon:lead_ore`,
			`eidolon:lead_ingot`,
			`eidolon:lead_block`,
			`eidolon:lead_nugget`,
		]);
		const hideMetal = (mod, name, types) => {
			types.forEach(type => {
				const typeFirst = ['immersiveengineering'];
				const id = typeFirst.includes(mod) ?
					`${mod}:${type}_${name}` :
					`${mod}:${name}_${type}`;
				if (!Ingredient.of(id).stacks.empty) {
					e.hide(id);
					//console.log(`Hid ${id}`);
				}
			});
		};
	
		const hideStuff = (mod, type, names) => {
			names.forEach(name => {
				const typeFirst = ['immersiveengineering'];
				const id = typeFirst.includes(mod) ?
					`${mod}:${type}_${name}` :
					`${mod}:${name}_${type}`;
				if (!Ingredient.of(id).stacks.empty) {
					e.hide(id);
					//console.log(`Hid ${id}`);
				}
			});
		};
	
		//Hides items based name, format: `mod`, `metal`, [`type1`, `type2`, `etc`]
		hideMetal(`immersiveengineering`, `copper`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `silver`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `aluminum`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `uranium`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `lead`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `nickel`, [`ingot`, `ore`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `steel`, [`ingot`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `electrum`, [`ingot`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`immersiveengineering`, `constantan`, [`ingot`, `dust`, `nugget`, `storage`, `slab_storage`]);
		hideMetal(`create`, `zinc`, [`ingot`, `ore`, `nugget`, `block`]);
		hideMetal(`thermal`, `copper`, [`ingot`, `ore`, `dust`, `nugget`, `block`]);
		hideMetal(`thermal`, `tin`, [`ingot`, `ore`, `dust`, `nugget`, `block`]);
		hideMetal(`thermal`, `lead`, [`ingot`, `ore`, `dust`, `nugget`, `block`]);
		hideMetal(`thermal`, `silver`, [`ingot`, `ore`, `dust`, `nugget`, `block`]);
		hideMetal(`thermal`, `nickel`, [`ingot`, `ore`, `dust`, `nugget`, `block`]);
	
		//Hides items based on type, format: `mod`, `type`, [`name1`, `name2`, `etc`]
		hideStuff(`thermal`, `dust`, [`iron`, `gold`]);
		hideStuff(`immersiveengineering`, `dust`, [`iron`, `gold`, `sulfur`, `wood`]);
		hideStuff(`immersiveengineering`, `plate`, [`iron`, `gold`, `copper`, `aluminum`, `lead`, `silver`, `nickel`, `constantan`, `electrum`]);
		hideStuff(`create`, `sheet`, [`iron`, `golden`, `copper`]);
		hideStuff(`iceandfire`, `ore`, [`silver`, `copper`]);
		hideStuff(`quark`, `crate`, [`apple`, `carrot`, `beetroot`, `potato`]);
		hideStuff(`quark`, `block`, [`bamboo`, `charcoal`, `sugar_cane`]);
	});
})