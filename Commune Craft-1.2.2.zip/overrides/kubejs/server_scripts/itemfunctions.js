onEvent('item.right_click', event => {
    if (event.hand == MAIN_HAND)
    if (event.item.id == 'kubejs:tomarian_ring_of_rejuvenation')
        event.server.schedule(5, event.server, function (callback) { 
        callback.server.runCommandSilent(`effect give @p minecraft:absorption`);
})})