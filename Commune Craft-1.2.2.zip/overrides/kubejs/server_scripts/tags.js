// priority 1000
onEvent('item.tags', e => {
    e.add('forge:gears',['kubejs:gear_steel']);
    e.add('forge:gears/steel',['kubejs:gear_steel']);
    e.add('curios:ring',['kubejs:tomarian_ring_of_rejuvenation']);
    e.add('forge:gems',['kubejs:red_tomarian_emerald']);
    e.add('forge:gems/redtomarianemrald',['kubejs:red_tomarian_emerald']);
})