events.listen('recipes', function(e) {
    //Angel Ring Section

    // Malleable Alloy
    e.recipes.create.mixing('kubejs:malleable_alloy', [
        'create:chromatic_compound',
        'thermal:basalz_powder',
        'thermal:blitz_powder',
        'thermal:blizz_powder'
    ]).superheated()
    // Mundane Ring 
    e.recipes.create.compacting('kubejs:mundane_ring', [
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy'
    ]).superheated()

    // Small Tweak Section

    // Chests 
    e.shaped('4x minecraft:chest', [
        'LLL',
        'L L',
        'LLL'
      ], {
        L: '#minecraft:logs'
      })
    // Steel Gear
    e.shaped('kubejs:gear_steel', [
      ' S ',
      'SNS',
      ' S '
    ], {
      S: '#forge:ingots/steel',
      N: '#forge:nuggets/iron'
    })
})
