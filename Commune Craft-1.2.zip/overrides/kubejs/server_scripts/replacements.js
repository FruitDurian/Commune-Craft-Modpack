
events.listen('recipes', function(e) {
    //Functions

    function modifyShaped(result, count, pattern, ingridients) {
        e.remove({
            output: result,
            type: 'minecraft:crafting_shaped'
        })
        e.shaped(item.of(result, count),
            pattern,
            ingridients
        ).id(`kubejs_` + result)
    }
    //Angel Ring//
    modifyShaped('doomangelring:itemdoomangelring', 1, [
        'ABF',
        'CHE',
        'FDA'
    ], {
        A: 'upgradednetherite:ultimate_upgraded_netherite_ingot',
        B: 'minecraft:elytra',
        C: 'pneumaticcraft:jet_boots_upgrade_5',
        D: 'ars_nouveau:glyph_glide',
        E: 'mythicbotany:aura_ring_greatest',
        F: 'botania:gaia_ingot',
        H: 'kubejs:mundane_ring'
    })
    //Integrated Dynamic Section

    // Squeezer
    modifyShaped('integrateddynamics:squeezer', 1, [
        'sSs',
        's s',
        'pMp'
    ], {
        s: 'minecraft:stick',
        S: '#forge:storage_blocks/steel',
        p: '#minecraft:planks',
        M: 'thermal:machine_frame'
    })
    // Thermal Seciton

    // Machine Frame
    modifyShaped('thermal:machine_frame', 1, [
        'sgs',
        'gTg',
        'sgs'
    ], {
        s: '#forge:ingots/steel',
        g: '#forge:glass',
        T: '#forge:gears/tin'
    })
    // Redstone Furnace
    modifyShaped('thermal:machine_furnace', 1, [
        ' R ',
        'bMb',
        'CrC'
    ], {
        b: 'minecraft:bricks',
        R: 'minecraft:redstone_block',
        M: 'thermal:machine_frame',
        C: '#forge:gears/copper',
        r: 'thermal:rf_coil'
    })
    // Saw Blade
    modifyShaped('thermal:saw_blade', 1, [
        'ss ',
        'scs',
        ' ss'
    ], {
        s: '#forge:ingots/steel',
        c: '#forge:ingots/copper'
    })
    // Drill Head
    modifyShaped('thermal:drill_head', 1, [
        ' s ',
        'scs',
        'sss'
    ], {
        s: '#forge:ingots/steel',
        c: '#forge:ingots/copper'
    })
    // Fluxbore
    modifyShaped('thermal:flux_drill', 1, [
        ' H ',
        'sGs',
        'TBT'
    ], {
        s: '#forge:ingots/steel',
        H: 'thermal:drill_head',
        B: 'thermal:energy_cell',
        G: '#forge:gears/gold',
        T: '#forge:gears/tin'
    })
    // Fluxsaw
    modifyShaped('thermal:flux_saw', 1, [
        ' H ',
        'sGs',
        'TBT'
    ], {
        s: '#forge:ingots/steel',
        H: 'thermal:saw_blade',
        B: 'thermal:energy_cell',
        G: '#forge:gears/gold',
        T: '#forge:gears/tin'
    })
    // Tinkers Workbench
    modifyShaped('thermal:tinker_bench', 1, [
        'SSS',
        'GCG',
        'pfp'
    ], {
        S: '#forge:storage_blocks/steel',
        G: '#forge:glass',
        C: 'minecraft:crafting_table',
        f: 'thermal:rf_coil',
        p: '#minecraft:planks'
    })
    // Dynamo's
    modifyShaped('thermal:dynamo_stirling', 1, [
        ' f ',
        'sGs',
        'SRS'
    ], {
        s: '#forge:ingots/steel',
        f: 'thermal:rf_coil',
        G: 'kubejs:gear_steel',
        S: '#forge:stone',
        R: 'minecraft:redstone_block'
    })
    modifyShaped('thermal:dynamo_compression', 1, [
        ' f ',
        'sGs',
        'BRB'
    ], {
        s: '#forge:ingots/steel',
        f: 'thermal:rf_coil',
        G: '#forge:gears/bronze',
        B: '#forge:ingots/bronze',
        R: 'minecraft:redstone_block'
    })
    modifyShaped('thermal:dynamo_magmatic', 1, [
        ' f ',
        'sGs',
        'BRB'
    ], {
        s: '#forge:ingots/steel',
        f: 'thermal:rf_coil',
        G: '#forge:gears/invar',
        B: '#forge:ingots/invar',
        R: 'minecraft:redstone_block'
    })
    modifyShaped('thermal:dynamo_numismatic', 1, [
        ' f ',
        'sGs',
        'BRB'
    ], {
        s: '#forge:ingots/steel',
        f: 'thermal:rf_coil',
        G: '#forge:gears/tin',
        B: '#forge:ingots/constantan',
        R: 'minecraft:redstone_block'
    })
    modifyShaped('thermal:dynamo_lapidary', 1, [
        ' f ',
        'sGs',
        'BRB'
    ], {
        s: '#forge:ingots/steel',
        f: 'thermal:rf_coil',
        G: '#forge:gears/gold',
        B: '#forge:storage_blocks/lapis',
        R: 'minecraft:redstone_block'
    })


})


