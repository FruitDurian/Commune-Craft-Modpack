events.listen('item.registry', function(e) {
    e.create('mundane_ring').displayName('Mundane Ring').unstackable()
    e.create('malleable_alloy').displayName('Malleable Alloy')
    e.create('red_tomarian_emerald').displayName('Red Tomarian Emerald')
    e.create('tomarian_ring_of_rejuvenation').displayName('§cTomarian Ring of Rejuvenation (NYI)').unstackable()
})