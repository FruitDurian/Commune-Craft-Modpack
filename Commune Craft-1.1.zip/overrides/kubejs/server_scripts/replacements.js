
events.listen('recipes', function(e) {
    //Functions

    function modifyShaped(result, count, pattern, ingridients) {
        e.remove({
            output: result,
            type: 'minecraft:crafting_shaped'
        })
        e.shaped(item.of(result, count),
            pattern,
            ingridients
        ).id(`kubejs_` + result)
    }
    modifyShaped('doomangelring:itemdoomangelring', 1, [
        'ABF',
        'CHE',
        'FDA'
    ], {
        A: 'upgradednetherite:ultimate_upgraded_netherite_ingot',
        B: 'minecraft:elytra',
        C: 'pneumaticcraft:jet_boots_upgrade_5',
        D: 'ars_nouveau:glyph_glide',
        E: 'mythicbotany:aura_ring_greatest',
        F: 'botania:gaia_ingot',
        H: 'kubejs:mundane_ring'
    })
})


