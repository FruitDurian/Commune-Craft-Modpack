events.listen('recipes', function(e) {
    // Malleable Alloy
    e.recipes.create.mixing('kubejs:malleable_alloy', [
        'create:chromatic_compound',
        'thermal:basalz_powder',
        'thermal:blitz_powder',
        'thermal:blizz_powder'
    ]).superheated()
    // Mundane Ring 
    e.recipes.create.compacting('kubejs:mundane_ring', [
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy',
        'kubejs:malleable_alloy'
    ]).superheated()
    // Chests 
    e.shaped('4x minecraft:chest', [
        'LLL',
        'L L',
        'LLL'
      ], {
        L: '#minecraft:logs'
      })
})
