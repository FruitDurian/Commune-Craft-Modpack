events.listen('recipes', function(e) {
    // Easy Angel Ring Ban
    e.remove({
        output: [
            'botania:flight_tiara' 
        ]
    })
  })